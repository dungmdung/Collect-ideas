﻿namespace Common.Constant
{
    public class Settings
    {
        public const int DefaultPageSize = 10;
        public const int DefaultPageIndex = 1;
        public const int MinimumUserAge = 17;
    }
}
