﻿namespace Common.Enums
{
    public enum ThumbEnum
    {
        ThumbUp,
        ThumbDown
    }
}
