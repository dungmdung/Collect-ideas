﻿namespace Common.Enums
{
    public enum SortDirection
    {
        Ascending = 0,
        Descending = 1
    }
}
