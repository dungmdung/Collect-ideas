﻿namespace Common.Enums
{
    public enum DepartmentEnum
    {
        None,
        IT,
        BusinessManagement,
        GraphicDesign,
        Marketing,
        EventManagement,
        InternationalBussiness,
        MediaManagement
    }
}
