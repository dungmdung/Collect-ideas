﻿namespace API.DTOs.Category
{
    public class CategoryModel
    {
        public int Id { get; set; }

        public string? CategoryName { get; set; }

        public string? CategoryDescription { get; set; }
    }
}
