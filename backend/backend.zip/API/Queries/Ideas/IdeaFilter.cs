﻿namespace API.Queries.Ideas
{
    public class IdeaFilter
    {
        public string? Department { get; set; }

        public string? CategoryName { get; set; }

        public string? EventName { get; set; }
    }
}
