﻿namespace API.Queries.Events
{
    public class EventFilter
    {
        public string? EventName { get; set; }

        public string? Department { get; set; }
    }
}
