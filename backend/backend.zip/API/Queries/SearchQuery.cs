﻿namespace API.Queries
{
    public class SearchQuery
    {
        public string? SearchValue { get; set; }
    }
}
