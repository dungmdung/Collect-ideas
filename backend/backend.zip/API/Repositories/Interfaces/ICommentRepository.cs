﻿using Data.Entities;

namespace API.Repositories.Interfaces
{
    public interface ICommentRepository : IBaseRepository<Comment>
    {
    }
}
