﻿using Data.Entities;

namespace API.Repositories.Interfaces
{
    public interface IEventRepository : IBaseRepository<Event>
    {
    }
}
