﻿using Data.Entities;

namespace API.Repositories.Interfaces
{
    public interface IIdeaRepository : IBaseRepository<Idea>
    {
    }
}
