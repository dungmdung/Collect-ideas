﻿using Data.Entities;

namespace API.Repositories.Interfaces
{
    public interface IThumbRespository : IBaseRepository<Thumb>
    {
    }
}
