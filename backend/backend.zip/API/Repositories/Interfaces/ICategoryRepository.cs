﻿using Data.Entities;

namespace API.Repositories.Interfaces
{
    public interface ICategoryRepository : IBaseRepository<Category>
    {
    }
}
