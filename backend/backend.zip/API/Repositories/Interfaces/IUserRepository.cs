﻿using Data.Entities;

namespace API.Repositories.Interfaces
{
    public interface IUserRepository : IBaseRepository<User>
    {
    }
}
